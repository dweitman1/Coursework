/* Daniel Weitman
 * COSC-350
 * Park
 * 4/5/19
 */

#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]){
    
    printf("Hello?\n");
}
