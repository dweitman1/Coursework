Daniel Weitman
COSC-320

(a)
Matrix addition, subtraction, and scalar multiplication have trivial algorithms, yet for matrix multiplication the algorithms starts by determining whether or not matrix multiplication is defined. Then the algorithm loops through every row then every column and then loops for every dot product.

(b) 
nxn         time
100         0.9702s
1000        10.7053s
10000       109.2023s

(c)
+(x) = O(n^2)
-(x) = O(n^2) 
*(x) = O(n^3)

(d)
Implementing an updated matrix multiplication algorithm with better asymptotic running time.


